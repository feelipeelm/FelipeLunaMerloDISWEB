"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var number = 4;

var saludar = function saludar() {
  return "¡Hola!";
};

var goodbye = function goodbye() {
  return "¡Adiós!";
};

var Clase = function Clase() {
  _classCallCheck(this, Clase);
};

// Se añade otroNombre al módulo
var f1 = function f1() {
  return 42;
}; // Se crea un módulo y se añade f1


; // Se añade f2 al módulo (default)

console.log("Prueba ejecución");