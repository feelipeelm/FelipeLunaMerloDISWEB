module.exports = {
  module: {
    rules: [
      {
        use: "babel-loader"
      }
    ]
  }
};
